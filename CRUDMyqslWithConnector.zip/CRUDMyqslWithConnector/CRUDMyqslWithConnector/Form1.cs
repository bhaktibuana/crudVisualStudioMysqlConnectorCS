﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUDMyqslWithConnector
{
    public partial class Form1 : Form
    {

        MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = kontak");
        DataTable dataTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fillDataKontak();
        }

        public DataTable getDataKontak()
        {
            dataTable.Reset();
            dataTable = new DataTable();
            using (MySqlCommand command = new MySqlCommand("SELECT * FROM data_kontak", connection))
            {
                connection.Open();

                MySqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
            return dataTable;
        }

        public void fillDataKontak()
        {
            dgv_dataKontak.DataSource = getDataKontak();

            DataGridViewButtonColumn colEditKontak = new DataGridViewButtonColumn();
            colEditKontak.UseColumnTextForButtonValue = true;
            colEditKontak.Text = "Edit";
            colEditKontak.Name = "";
            dgv_dataKontak.Columns.Add(colEditKontak);

            DataGridViewButtonColumn colDeleteKontak = new DataGridViewButtonColumn();
            colDeleteKontak.UseColumnTextForButtonValue = true;
            colDeleteKontak.Text = "Delete";
            colDeleteKontak.Name = "";
            dgv_dataKontak.Columns.Add(colDeleteKontak);
        }
    }
}
